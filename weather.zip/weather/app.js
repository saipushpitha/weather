var app = angular.module('weatherApp', []);

app.controller('weatherController', function($scope) {
    $scope.city = '';
    $scope.temperature = null;
    $scope.errorMessage = '';
    $scope.showTemperature = false;

    $scope.getTemperature = function() {
        // Convert city name to lowercase for case-insensitive comparison
        var cityLower = $scope.city.toLowerCase();
        
        // Dictionary to store temperature data
        var temperatureData = {
            'vizag': 32,
            'hyderabad': 30,
            'odisha': 29,
            'manali': 1,
            'jaipur': 29
        };

        // Look up temperature based on entered city
        if (temperatureData.hasOwnProperty(cityLower)) {
            $scope.temperature = temperatureData[cityLower];
            $scope.errorMessage = '';
            $scope.showTemperature = true; // Show temperature after successful lookup
        } else {
            $scope.temperature = null;
            $scope.errorMessage = 'Temperature data not available for ' + $scope.city;
            $scope.showTemperature = false; // Hide temperature if data is not available
        }
    };
});